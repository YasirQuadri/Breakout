package com.mygdx.breakout;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.GlyphLayout;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Vector;
import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.utils.Align;
import com.badlogic.gdx.utils.Array;
import com.badlogic.gdx.utils.ScreenUtils;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.math.Circle;

import java.util.Iterator;

public class Breakout extends ApplicationAdapter {
	SpriteBatch batch;

	private OrthographicCamera camera;

	private Rectangle paddle;
	private Array<Rectangle> bricks;
	private Rectangle ball;

	BitmapFont font;
	GlyphLayout layout;

	private boolean gameover = false;
	private  boolean levelComplete = false;
	private int ballXspeed = 3;
	private int ballYspeed = 3;
	private int score = 0;

	private static final int screenWidh = 900;
	private static final int screenheight = 500;

	private Texture ballImage;
	private Texture paddleImage;
	private Texture brickImage;

	private static final  int numberOfBricks = 8;		//number of bricks per row
	private static final  int numberOfRows = 3;			//number of rows to generate

	@Override
	public void create ()
	{
		camera = new OrthographicCamera();
		camera.setToOrtho(false,screenWidh,screenheight);

		batch = new SpriteBatch();
		font = new BitmapFont();
		layout = new GlyphLayout();

		ballImage = new Texture(Gdx.files.internal("ball.png"));
		brickImage = new Texture(Gdx.files.internal("brick.png"));
		paddleImage = new Texture(Gdx.files.internal("pedal.png"));

		//initialize paddle
		paddle = new Rectangle();
		paddle.x = 400;
		paddle.y = 20;
		paddle.width = 100;
		paddle.height = 20;

		//initialize ball
		ball = new Rectangle();
		ball.x = 300;
		ball.y = 200;
		ball.width = 10;
		ball.height = 10;

		//initialize bricks
		bricks = new Array<Rectangle>(10);

		//will generate a grid of bricks on the game screen
		for(int i = 1; i<=numberOfRows ; i++)
		{
			for(int j = 1; j<=numberOfBricks; j++)
			{
				brickGenerator(i,j);
			}
		}
	}

	@Override
	public void render () {
		ScreenUtils.clear(0, 0, 0, 1);
		camera.update();
		batch.setProjectionMatrix(camera.combined);
		batch.begin();
		batch.draw(ballImage ,ball.x,ball.y);
		batch.draw(paddleImage, paddle.x, paddle.y);
		//will draw all the bricks present in bricks array
		for(Rectangle brick:bricks)
		{
			batch.draw(brickImage, brick.x, brick.y);
		}
		drawUI();
		// prompt to show restart key
		if(gameover||levelComplete)
		{
			layout.setText(font,"Press R to reset the game",Color.RED,0,Align.center,true);
			font.draw(batch,layout,screenWidh/2 -10,screenheight/4);
		}
		batch.end();

		checkCollision();

		//disables paddle and ball movement when gameover is true
		if(!gameover && !levelComplete)
		{
			ballMovement();
			paddleMovement();
		}

		// press r to reset the game
		if(Gdx.input.isKeyPressed(Input.Keys.R))
		{
				resetGame();
		}
	}

	// will reset the game to its original state and set position of ball and paddle to their default values
	private  void resetGame()
	{
			gameover = false;
			levelComplete = false;
			score =0;
			paddle.x = 400;
			ball.x = 300;
			ball.y = 200;
			ballXspeed = 3;

			// will generate bricks for a new stage
			bricks.clear();
			for (int i = 1; i <= numberOfRows; i++)
			{
				for (int j = 1; j <= numberOfBricks; j++)
				{
					brickGenerator(i, j);
				}
			}
	}




	//takes input from user and accelerates the paddle 400 pixels per second in that direction.
	private void paddleMovement()
	{
		if(Gdx.input.isKeyPressed(Input.Keys.LEFT)) paddle.x -= 400 * Gdx.graphics.getDeltaTime();
		if(Gdx.input.isKeyPressed(Input.Keys.RIGHT)) paddle.x += 400 * Gdx.graphics.getDeltaTime();

		//stops the paddle from leaving game field
		if(paddle.x < 5) paddle.x =5;
		if(paddle.x > 900 - 105) paddle.x = 900 -105;
	}

	//will make the ball move diagonally when the game starts or resets
	private void ballMovement()
	{
		ball.x += ballXspeed;
		ball.y += ballYspeed;

		//reflects the ball away from edges of the screen
		if(ball.y >screenheight -20) ballYspeed *= -1;
		if(ball.x > screenWidh -20) ballXspeed *= -1;
		if(ball.x <5) ballXspeed *= -1;

		//sets game over to true when balls falls down
		if(ball.y <0)
		{
			gameover = true;
		}

		if(Gdx.input.isTouched() && score >=22)
		{
			Vector3 touchpos = new Vector3();
			touchpos.set(Gdx.input.getX(),Gdx.input.getY(),0);
			camera.unproject(touchpos);
			ball.x = touchpos.x -10;
			ball.y = touchpos.y -10;
		}
	}

	//will check when ball collides with anything
	private void checkCollision()
	{
		// reflects ball when it touches paddle
		if(ball.overlaps(paddle)) ballYspeed *= -1;

		//will check if ball collides with brick and destroy that brick
		for(Iterator<Rectangle> iter = bricks.iterator(); iter.hasNext();)
		{
			Rectangle brick =iter.next();
			if(ball.overlaps(brick))
			{
				score ++;
				ballYspeed *= -1;
				iter.remove();
			}

			// sets gameover flag to true if all bricks are destroyed.
			if(bricks.isEmpty())
			{
				levelComplete = true;
				System.out.println("game over");
			}
		}

	}

	//created a single brick on the screen based on given parameters
	private void brickGenerator(int rowNumber,int brickNumber)
	{
		Rectangle brick = new Rectangle();
		brick.height=10;
		brick.width = 50;

		//will set x and y position of bricks based on their iteration
		//the value 90 and rownumber*40 are just intervals in position i saw fit for generating bricks.
		brick.x = 90 * brickNumber;
		brick.y = screenheight -(rowNumber * 40);
		bricks.add(brick);
	}

	private  void drawUI()
	{
		Color fontColour =new Color(Color.WHITE);
		layout.setText(font,"Score :" +String.valueOf(score),fontColour,0, Align.center,true);
		float x = screenWidh/2 -15;
		float y = screenheight - 5;
		font.draw(batch, layout, x, y);

		String abilityUnlocked = "Ability Unlocked: You can control the ball with Mouse Pointer";

		if(score>=22 &&(!gameover || levelComplete))
		{
			layout.setText(font,abilityUnlocked,fontColour,0,Align.center,true);
			font.draw(batch,layout,x,screenheight/3);
		}
		if(gameover)
		{
			layout.setText(font,"Game Over",fontColour,0,Align.center,true);
			font.draw(batch,layout,x,screenheight/2);
		}
		if(levelComplete)
		{
			layout.setText(font,"Level Completed",fontColour,0,Align.center,true);
			font.draw(batch,layout,x,screenheight/2);
		}
	}

	@Override
	public void dispose () {
		batch.dispose();
		paddleImage.dispose();
		ballImage.dispose();
		brickImage.dispose();
	}
}
